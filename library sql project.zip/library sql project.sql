create database libraryy;
use libraryy;
drop table authors;
drop table bookcopies;
drop table book_loans;
drop table books;
drop table publisher;
drop table library_branch;
drop table borrower;
create table publisher(
publisher_PublisherName varchar(100) primary key,
publisher_PublisherAddress varchar(255),
publisher_PublisherPhone varchar(30));
create table borrower(
borrower_CardNo int primary key,
borrower_BorrowerName varchar(100),
borrower_BorrowerAddress varchar(300),
borrower_BorrowerPhone varchar(100));
create table library_branch(
library_branch_BranchID int auto_increment primary key,
library_branch_BranchName varchar(30),
library_branch_BranchAddress varchar(30));
create table books(
ï»¿book_BookID int auto_increment primary key,
book_Title varchar(60),
book_PublisherName varchar(30),
foreign key (book_PublisherName) references publisher(publisher_PublisherName)
on delete cascade on update cascade);
create table authors(
ï»¿book_authors_BookID int auto_increment,
book_authors_AuthorName varchar(40),
foreign key (ï»¿book_authors_BookID) references books(ï»¿book_BookID)
on delete cascade on update cascade);
create table book_loans(
ï»¿book_loans_BookID int,
book_loans_BranchID int,
book_loans_CardNo int,
book_loans_DateOut varchar(30),
book_loans_DueDate varchar(30),
foreign key (ï»¿book_loans_BookID)  references books(ï»¿book_BookID),
foreign key (book_loans_BranchID)  references library_branch(library_branch_BranchID),
foreign key (book_loans_CardNo)  references borrower(borrower_CardNo)
on delete cascade on update cascade);
create table bookcopies(
ï»¿book_copies_BookID int,
book_copies_BranchID int,
book_copies_No_Of_Copies int,
foreign key (ï»¿book_copies_BookID) references books(ï»¿book_BookID),
foreign key (book_copies_BranchID) references book_loans(book_loans_BranchID)
on delete cascade on update cascade);

-- 1.How many copies of the book titled "The Lost Tribe" are owned by the library branch whose name is "Sharpstown"?
select book_copies_BranchID,sum(book_copies_No_Of_Copies) from bookcopies
where book_copies_BranchID=1 and ï»¿book_copies_BookID=20
group by book_copies_BranchID;

-- 2.How many copies of the book titled "The Lost Tribe" are owned by each library branch?
select book_copies_BranchID,sum(book_copies_No_Of_Copies) from bookcopies
where ï»¿book_copies_BookID=20
group by ï»¿book_copies_BookID,book_copies_BranchID;

-- 3.Retrieve the names of all borrowers who do not have any books checked out.
select borrower_BorrowerName from borrower as b
left join book_loans as bl
on b.borrower_CardNo=bl.book_loans_CardNo
where bl.book_loans_CardNo is null;

-- 4.For each book that is loaned out from the "Sharpstown" branch and whose DueDate is 2/3/18, retrieve the book title, 
-- the borrower's name, and the borrower's address.

select b.book_Title,br.borrower_BorrowerName,br.borrower_BorrowerAddress from book_loans as bl
join books as b
on b.ï»¿book_BookID=bl.ï»¿book_loans_BookID
join borrower as br
on br.borrower_CardNo=bl.book_loans_CardNo
where bl.book_loans_BranchID=1 and bl.book_loans_DueDate='2/3/18';

-- 5.For each library branch, retrieve the branch name and the total number of books loaned out from that branch.
with cte as
(select book_loans_branchid, count(*) as book_count from book_loans where book_loans_branchid in
(select library_branch_branchid from library_branch) group by book_loans_branchid)
select library_branch_branchname,book_count from cte join library_branch on cte.book_loans_branchid =  library_branch.library_branch_branchid;

-- 6.Retrieve the names, addresses, and number of books checked out for all borrowers who have more than five books checked out.
SELECT borrower.borrower_BorrowerName, borrower.borrower_BorrowerAddress, COUNT(book_loans.ï»¿book_loans_BookID) AS Books_Checked_Out
FROM borrower
INNER JOIN book_loans ON borrower.borrower_CardNo = book_loans.book_loans_CardNo
GROUP BY book_loans.book_loans_CardNo
HAVING COUNT(book_loans.ï»¿book_loans_BookID) > 5;

-- 7.For each book authored by "Stephen King", retrieve the title and the number of copies owned by the library branch
-- whose name is "Central".
SELECT books.book_Title, SUM(bookcopies.book_copies_No_Of_Copies) AS Total_Copies
FROM books
JOIN authors ON books.ï»¿book_BookID = authors.ï»¿book_authors_BookID
JOIN bookcopies ON books.ï»¿book_BookID = bookcopies.ï»¿book_copies_BookID
JOIN library_branch ON bookcopies.book_copies_BranchID = library_branch.library_branch_BranchID
WHERE authors.book_authors_AuthorName = 'Stephen King' AND library_branch.library_branch_BranchName = 'Central'
GROUP BY books.book_Title;




